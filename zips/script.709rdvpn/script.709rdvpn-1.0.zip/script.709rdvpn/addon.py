import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib2
import re
import sys

addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')

req = urllib2.Request("https://real-debrid.com/vpn")
response = urllib2.urlopen(req)
lines = response.readlines()

line1 = ""
line2 = ""
line3 = ""

vpnInfo = False
for line in lines:
    line = line.strip(' \t\n\r')
    x = re.search("[COLOR green][B]VPN Information[/B][/COLOR]", line)
    if not x == None:
       vpnInfo = True
    else:
       if vpnInfo and line != "":
         line1 = re.sub(r"\<[^>]+\>", "", line)
         vpnInfo = False

    x = re.search("[COLOR green][B]Your IP Address:[/B][/COLOR]", line)
    if not x == None:
      line2 = re.sub(r"\<[^>]+\>", "", line)

    x = re.search("[COLOR gray][B]Your IP Reverse:[/B][/COLOR]", line)
    if not x == None:
      line3 = re.sub(r"\<[^>]+\>", "", line)

    if line1 != "" and line2 != "" and line3 != "":
      break

if False:
  xbmcgui.Dialog().ok("https://real-debrid.com/vpn", line2, line3, line1)
else:
  lines = line1.split('.')
  for line in lines:
    li = xbmcgui.ListItem(line.strip(), iconImage='DefaultFolder.png')
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

  li = xbmcgui.ListItem(line2, iconImage='DefaultFolder.png')
  xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

  li = xbmcgui.ListItem(line3, iconImage='DefaultFolder.png')
  xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

  xbmcplugin.setContent(int(sys.argv[1]), 'files')
  xbmcplugin.endOfDirectory(int(sys.argv[1]))
