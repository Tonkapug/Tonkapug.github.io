# -*- coding: UTF-8 -*-

import os,time,xbmc,xbmcgui,urllib2

Debrid = xbmc.translatePath('special://home/addons/plugin.program.709Pair/resources/Debrid.png')
Trakt = xbmc.translatePath('special://home/addons/plugin.program.709Pair/resources/Trakt.png')

def menuoptions():
    dialog = xbmcgui.Dialog()
    funcs = (
        function1,
        function2,
        function3,
        function4,
        function5,
        function6,
        function7,
        function8,
        function9,
        )
        
    call = dialog.select('[B][COLOR=gray]709[/COLOR][COLOR=dodgerblue]Wizard[/COLOR] - RD & Trakt Pairing Utility[/B]', [
    '[B][COLOR=forestgreen]AUTHORIZE 1-5 for REAL-DEBRID[/COLOR][/B]',
    '[B]1. ResolveURL[/B]',
    '[B]2. Shadow[/B]',
    '[B]3. Foxy Streams[/B]', 
    '[B]4. Seren[/B]',
    '[B]5. Fen[/B]',
    '[B][COLOR=crimson]AUTHORIZE 1-2 for TRAKT[/COLOR][/B]',
    '[B]1. TMDB Helper[/B]',
    '[B]2. OpenMeta[/B]',])

    # dialog.selectreturns
    #   0 -> escape pressed
    #   1 -> first item
    #   2 -> second item
    if call:
        # esc is not pressed
        if call < 0:
            return
        func = funcs[call-9]
        return func()
    else:
        func = funcs[call]
        return func()
    return


def function1():
     xbmc.executebuiltin('ShowPicture('+Debrid+')')
	
def function2():
	xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")

def function3():
     	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.shadow?mode=138&url=www)")

def function4():     	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.foxystreams/?action=debrid_auth)")
	
def function5():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.seren/?action=authRealDebrid)")

def function6():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.authenticate)")

def function7():
     xbmc.executebuiltin('ShowPicture('+Trakt+')')

def function8():
	xbmc.executebuiltin("RunScript(plugin.video.themoviedb.helper, authenticate_trakt)")

def function9():
	xbmc.executebuiltin("RunPlugin(plugin://plugin.video.openmeta/authenticate_trakt)")
	
menuoptions()

