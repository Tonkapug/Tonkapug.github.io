                                                                   ##################################################################
#  This program is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by    #
#  the Free Software Foundation, either version 3 of the License, or       #
#  (at your option) any later version.                                     #
#                                                                          #
#  This program is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#  GNU General Public License for more details.                            #
#                                                                          #
############################################################################
import urllib,urllib2,webbrowser,sys,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,subprocess,time
from libs import addonwindow as pyxbmct
ADDON_ID         = 'script.709pair'
HOME             = xbmc.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
FANART           = os.path.join(PLUGIN,    'fanart.jpg')
ICON             = os.path.join(PLUGIN,    'icon.png')
ART              = os.path.join(PLUGIN,    'libs', 'art')
PUG              = pyxbmct.AddonDialogWindow('')
EXIT             = os.path.join(ART , 'redB.png')
FBUTTON          = os.path.join(ART , 'yellowB.png') 
BUTTON           = os.path.join(ART , 'button.png')
TITLE            = os.path.join(ART , 'title.png')
LOGO             = os.path.join(ART , 'logo.png')
LOGO1             = os.path.join(ART , 'debrid.png')
LOGO2             = os.path.join(ART , 'maintenance.png')
LOGO3             = os.path.join(ART , 'Trakt1.png')
LOGO4             = os.path.join(ART , 'Trakt2.png')
def site(items):
	if items == 'Seren':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.seren/?action=authRealDebrid)")
                time.sleep(3)
		PUG.setFocus(PAIR1)
                
	if items == 'Shadow':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.shadow?mode=138&url=www)")
                time.sleep(3)
		PUG.setFocus(PAIR2)

	if items == 'Fen':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=real_debrid.authenticate)")
                time.sleep(3)
		PUG.setFocus(PAIR3)

	if items == 'FoxyStreams':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.foxystreams/?action=debrid_auth)")
                time.sleep(3)
		PUG.setFocus(PAIR4)

        if items == 'Maintenance':
                xbmc.executebuiltin("Dialog.Close(all,true)")
                xbmc.executebuiltin("RunPlugin(plugin://script.709tools)")
		
	if items == 'ResolveURL':
                xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=auth_rd)")
		                                                                		
	if items == 'TMDBTrakt':
                xbmc.executebuiltin("RunScript(plugin.video.themoviedb.helper, authenticate_trakt)")
                time.sleep(3)
		PUG.setFocus(PAIR7)

	if items == 'OpenMetaTrakt':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.openmeta/authenticate_trakt)")
                time.sleep(3)
		PUG.setFocus(PAIR8)

	if items == 'SerenTrakt':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.seren/?action=authTrakt)")
                time.sleep(3)
		PUG.setFocus(PAIR9)

	if items == 'FenTrakt':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=trakt_authenticate)")
                time.sleep(3)
		PUG.setFocus(PAIR10)

	if items == 'NumbersTrakt':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.numbersbynumbers/?action=authTrakt)")
                time.sleep(3)
		PUG.setFocus(PAIR11)

	if items == 'VenomTrakt':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.venom/?action=authTrakt)")
                time.sleep(3)
		PUG.setFocus(PAIR12)

	if items == 'TheCrewTrakt':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.thecrew/?action=authTrakt)")
                time.sleep(3)
		PUG.setFocus(PAIR13)

	if items == 'MarauderTrakt':
                xbmc.executebuiltin("RunPlugin(plugin://plugin.video.marauder/?action=authTrakt)")
                time.sleep(3)
		PUG.setFocus(PAIR14)
#################################################################
dialog = xbmcgui.Dialog()
ok = dialog.ok('[B]Required Authorizations[/B] for this Build', '[COLOR teal][B]DEDRID[/B][/COLOR]                   [COLOR red][B]TRAKT[/B][/COLOR]\n1. Seren                   1. TMDB Helper\n2. Shadow               2. OpenMeta\n3. Fen\n4. FoxyStreams\n5. ResolveURL')

PUG.setGeometry(640, 360, 80, 40)
fan=pyxbmct.Image(FANART)
PUG.placeControl(fan, -20, -12, 145, 63)

logo=pyxbmct.Image(LOGO)
PUG.placeControl(logo, 54, 11, 40, 17)

titletx   = pyxbmct.Image(TITLE)
PUG.placeControl(titletx, -18, -6 , 20, 50)

logo=pyxbmct.Image(LOGO1)
PUG.placeControl(logo, 6, -11, 13, 15)

PAIR1= pyxbmct.Button('[B]Seren[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR1,19 , -11 , 13, 15)
PUG.connect(PAIR1, lambda: site('Seren'))

PAIR2= pyxbmct.Button('[B]Shadow[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR2,32 , -11 , 13, 15)
PUG.connect(PAIR2, lambda: site('Shadow'))

PAIR3= pyxbmct.Button('[B]Fen[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR3,45 , -11 , 13, 15)
PUG.connect(PAIR3, lambda: site('Fen'))

PAIR4= pyxbmct.Button('[B]Foxy[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR4,58 , -11 , 13, 15)
PUG.connect(PAIR4, lambda: site('FoxyStreams'))

PAIR5= pyxbmct.Button('[B]ResolveURL[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR5,71 , -11 , 13, 15)
PUG.connect(PAIR5, lambda: site('ResolveURL'))

logo=pyxbmct.Image(LOGO2)
PUG.placeControl(logo, 90, -11, 13, 15)

PAIR6= pyxbmct.Button('[B]Tools & Cache[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR6,103 , -11 , 13, 15)
PUG.connect(PAIR6, lambda: site('Maintenance'))

logo=pyxbmct.Image(LOGO3)
PUG.placeControl(logo, 6, 12, 13, 15)

PAIR7= pyxbmct.Button('[B]TMDB Helper[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR7,19 , 12 , 13, 15)
PUG.connect(PAIR7, lambda: site('TMDBTrakt'))

PAIR8= pyxbmct.Button('[B]OpenMeta[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR8,32 , 12 , 13, 15)
PUG.connect(PAIR8, lambda: site('OpenMetaTrakt'))

logo=pyxbmct.Image(LOGO4)
PUG.placeControl(logo, 6 , 35 , 13, 15)

PAIR9= pyxbmct.Button('[B]Seren[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR9,19 , 35 , 13, 15)
PUG.connect(PAIR9, lambda: site('SerenTrakt'))

PAIR10= pyxbmct.Button('[B]Fen[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR10,32 , 35 , 13, 15)
PUG.connect(PAIR10, lambda: site('FenTrakt'))

PAIR11= pyxbmct.Button('[B]NuMbErS[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR11,45 , 35 , 13, 15)
PUG.connect(PAIR11, lambda: site('NumbersTrakt'))

PAIR12= pyxbmct.Button('[B]Venom[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR12,58 , 35 , 13, 15)
PUG.connect(PAIR12, lambda: site('VenomTrakt'))

PAIR13= pyxbmct.Button('[B]The Crew[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR13,71 , 35 , 13, 15)
PUG.connect(PAIR13, lambda: site('TheCrewTrakt'))

PAIR14= pyxbmct.Button('[B]Marauder[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR14,84 , 35 , 13, 15)
PUG.connect(PAIR14, lambda: site('MarauderTrakt'))

CloseButton = pyxbmct.Button('[B]Close[/B]',focusTexture=EXIT,noFocusTexture=BUTTON)
PUG.placeControl(CloseButton,101 , 12 ,19, 15)
PUG.connect(CloseButton, PUG.close)

PAIR1.controlUp(PAIR6)
PAIR1.controlDown(PAIR2)
PAIR1.controlRight(PAIR7)
PAIR1.controlLeft(PAIR9)
PAIR2.controlUp(PAIR1)
PAIR2.controlDown(PAIR3)
PAIR2.controlRight(PAIR7)
PAIR2.controlLeft(PAIR9)
PAIR3.controlUp(PAIR2)
PAIR3.controlDown(PAIR4)
PAIR3.controlRight(PAIR7)
PAIR3.controlLeft(PAIR9)
PAIR4.controlUp(PAIR3)
PAIR4.controlDown(PAIR5)
PAIR4.controlRight(PAIR7)
PAIR4.controlLeft(PAIR9)
PAIR5.controlUp(PAIR4)
PAIR5.controlDown(PAIR6)
PAIR5.controlRight(PAIR7)
PAIR5.controlLeft(PAIR9)
PAIR6.controlUp(PAIR5)
PAIR6.controlDown(PAIR1)
PAIR6.controlRight(CloseButton)
PAIR6.controlLeft(PAIR9)
PAIR7.controlUp(PAIR8)
PAIR7.controlDown(PAIR8)
PAIR7.controlLeft(PAIR1)
PAIR7.controlRight(PAIR9)
PAIR8.controlUp(PAIR7)
PAIR8.controlLeft(PAIR1)
PAIR8.controlRight(PAIR9)
PAIR8.controlDown(CloseButton)
PAIR9.controlUp(PAIR14)
PAIR9.controlLeft(PAIR7)
PAIR9.controlDown(PAIR10)
PAIR9.controlRight(PAIR1)
PAIR10.controlUp(PAIR9)
PAIR10.controlLeft(PAIR7)
PAIR10.controlDown(PAIR11)
PAIR10.controlRight(PAIR1)
PAIR11.controlUp(PAIR10)
PAIR11.controlLeft(PAIR7)
PAIR11.controlDown(PAIR12)
PAIR11.controlRight(PAIR1)
PAIR12.controlUp(PAIR11)
PAIR12.controlLeft(PAIR7)
PAIR12.controlDown(PAIR13)
PAIR12.controlRight(PAIR1)
PAIR13.controlUp(PAIR12)
PAIR13.controlLeft(PAIR7)
PAIR13.controlDown(PAIR14)
PAIR13.controlRight(PAIR1)
PAIR14.controlUp(PAIR13)
PAIR14.controlLeft(CloseButton)
PAIR14.controlDown(PAIR9)
PAIR14.controlRight(PAIR1)
CloseButton.controlUp(PAIR8)
CloseButton.controlLeft(PAIR6)
CloseButton.controlRight(PAIR14)
PUG.setFocus(PAIR1)
PUG.connect(pyxbmct.ACTION_NAV_BACK, PUG.close)
PUG.doModal()
del PUG 
