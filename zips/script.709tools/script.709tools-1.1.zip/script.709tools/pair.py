                                                                   ##################################################################
#  This program is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by    #
#  the Free Software Foundation, either version 3 of the License, or       #
#  (at your option) any later version.                                     #
#                                                                          #
#  This program is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of          #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the           #
#  GNU General Public License for more details.                            #
#                                                                          #
############################################################################
import urllib,urllib2,webbrowser,sys,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os,subprocess,time
from libs import addonwindow as pyxbmct
ADDON_ID         = 'script.709tools'
HOME             = xbmc.translatePath('special://home/')
ADDONS           = os.path.join(HOME,      'addons')
USERDATA         = os.path.join(HOME,      'userdata')
PLUGIN           = os.path.join(ADDONS,    ADDON_ID)
FANART           = os.path.join(PLUGIN,    'fanart.jpg')
ICON             = os.path.join(PLUGIN,    'icon.png')
ART              = os.path.join(PLUGIN,    'libs', 'art')
PUG              = pyxbmct.AddonDialogWindow('')
EXIT             = os.path.join(ART , 'redB.png')
FBUTTON          = os.path.join(ART , 'yellowB.png') 
BUTTON           = os.path.join(ART , 'button.png')
TITLE            = os.path.join(ART , 'title.png')
LOGO             = os.path.join(ART , 'logo.png')
LOGO1             = os.path.join(ART , 'tools.png')
LOGO2             = os.path.join(ART , 'auth.png')
LOGO3             = os.path.join(ART , 'resolver.png')
LOGO4             = os.path.join(ART , 'addons.png')
def site(items):
	if items == 'CleanKodi':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.program.709wizard/?mode=fullclean&quot;)")
		xbmc.executebuiltin("Dialog.Close(all,true)")
		
	if items == 'VideoBuff':
		xbmc.executebuiltin("RunPlugin(plugin://script.ezmaintenanceplus/?url=ur&amp;action=adv_settings&amp)")
		
	if items == 'AddonTools':
		xbmc.executebuiltin("Dialog.Close(all,true)")
		time.sleep(2)
		xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.program.709wizard/?mode=maint&amp;name=addon;,return)")
		
	if items == 'RURL_Settings':
		xbmc.executebuiltin("Addon.OpenSettings(script.module.resolveurl)")
		
	if items == 'Auth':
                xbmc.executebuiltin("Dialog.Close(all,true)")
                xbmc.executebuiltin("RunPlugin(plugin://script.709pair)")
				
	if items == 'RURL_Clear':
		xbmc.executebuiltin("RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)")
		
	if items == 'URLR_Clear':
		xbmc.executebuiltin("RunPlugin(plugin://script.module.urlresolver/?mode=reset_cache)")
		
	if items == 'SerenClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.seren/?action=clearCache)")
		
	if items == 'ShadowClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.shadow/?url=www&mode=35)")
		
	if items == 'FenClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.fen/?mode=clear_all_cache&amp)")
		time.sleep(5)
		PUG.setFocus(PAIR10)
				
	if items == 'NumbersClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.numbersbynumbers/?action=clearAllCache&quot;,return)")
		
	if items == 'VenomClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.venom/?action=clearAllCache&amp)")
		
	if items == 'TheCrewClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.thecrew/?action=clearAllCache&quot;,return)")
		
	if items == 'MarauderClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.marauder/?action=clearCacheProviders)")

        if items == 'MetaClear':
		xbmc.executebuiltin("RunPlugin(plugin://plugin.video.openmeta/clear_cache)")
		
	if items == 'InfoClear':
		xbmc.executebuiltin("RunScript(script.extendedinfo,info=deletecache)")
		
#################################################################
PUG.setGeometry(640, 360, 80, 40)
fan=pyxbmct.Image(FANART)
PUG.placeControl(fan, -40, -12, 165, 64)

logo=pyxbmct.Image(LOGO)
PUG.placeControl(logo, 44, 11, 40, 17)

titletx   = pyxbmct.Image(TITLE)
PUG.placeControl(titletx, -38, -6 , 20, 50)

logo=pyxbmct.Image(LOGO1)
PUG.placeControl(logo, -14, -11, 13, 15)

PAIR1= pyxbmct.Button('[B]Clean Kodi[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR1,-1 , -11 , 13, 15)
PUG.connect(PAIR1, lambda: site('CleanKodi'))

PAIR2= pyxbmct.Button('[B]Video Buffer[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR2,12 , -11 , 13, 15)
PUG.connect(PAIR2, lambda: site('VideoBuff'))

PAIR3= pyxbmct.Button('[B]Addon Tools[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR3,25 , -11 , 13, 15)
PUG.connect(PAIR3, lambda: site('AddonTools'))

PAIR4= pyxbmct.Button('[B]ResolveURL Config[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR4,38 , -11 , 13, 15)
PUG.connect(PAIR4, lambda: site('RURL_Settings'))

logo=pyxbmct.Image(LOGO2)
PUG.placeControl(logo, 64, -11, 13, 15)

PAIR5= pyxbmct.Button('[B]Debrid & Trakt[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR5,77 , -11 , 13, 15)
PUG.connect(PAIR5, lambda: site('Auth'))

logo=pyxbmct.Image(LOGO3)
PUG.placeControl(logo, -14, 12, 13, 15)

PAIR6= pyxbmct.Button('[B]ResolveURL[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR6,-1 , 12 , 13, 15)
PUG.connect(PAIR6, lambda: site('RURL_Clear'))

PAIR7= pyxbmct.Button('[B]URLresolver[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR7,12 , 12 , 13, 15)
PUG.connect(PAIR7, lambda: site('URLR_Clear'))

logo=pyxbmct.Image(LOGO4)
PUG.placeControl(logo, -14 , 35 , 13, 15)

PAIR8= pyxbmct.Button('[B]Seren[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR8,-1 , 35 , 13, 15)
PUG.connect(PAIR8, lambda: site('SerenClear'))

PAIR9= pyxbmct.Button('[B]Shadow[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR9,12 , 35 , 13, 15)
PUG.connect(PAIR9, lambda: site('ShadowClear'))

PAIR10= pyxbmct.Button('[B]Fen[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR10,25 , 35 , 13, 15)
PUG.connect(PAIR10, lambda: site('FenClear'))

PAIR11= pyxbmct.Button('[B]NuMbErS[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR11,38 , 35 , 13, 15)
PUG.connect(PAIR11, lambda: site('NumbersClear'))

PAIR12= pyxbmct.Button('[B]Venom[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR12,51 , 35 , 13, 15)
PUG.connect(PAIR12, lambda: site('VenomClear'))

PAIR13= pyxbmct.Button('[B]The Crew[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR13,64 , 35 , 13, 15)
PUG.connect(PAIR13, lambda: site('TheCrewClear'))

PAIR14= pyxbmct.Button('[B]Marauder[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR14,77 , 35 , 13, 15)
PUG.connect(PAIR14, lambda: site('MarauderClear'))

PAIR15= pyxbmct.Button('[B]OpenMeta[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR15,90 , 35 , 13, 15)
PUG.connect(PAIR15, lambda: site('MetaClear'))

PAIR16= pyxbmct.Button('[B]OpenInfo[/B]' ,focusTexture=FBUTTON,noFocusTexture=BUTTON)
PUG.placeControl(PAIR16,103 , 35 , 13, 15)
PUG.connect(PAIR16, lambda: site('InfoClear'))

CloseButton = pyxbmct.Button('[B]Close[/B]',focusTexture=EXIT,noFocusTexture=BUTTON)
PUG.placeControl(CloseButton,105 , 12 ,19, 15)
PUG.connect(CloseButton, PUG.close)

PAIR1.controlUp(PAIR5)
PAIR1.controlDown(PAIR2)
PAIR1.controlRight(PAIR6)
PAIR1.controlLeft(PAIR8)
PAIR2.controlUp(PAIR1)
PAIR2.controlDown(PAIR3)
PAIR2.controlRight(PAIR6)
PAIR2.controlLeft(PAIR8)
PAIR3.controlUp(PAIR2)
PAIR3.controlDown(PAIR4)
PAIR3.controlRight(PAIR6)
PAIR3.controlLeft(PAIR8)
PAIR4.controlUp(PAIR3)
PAIR4.controlDown(PAIR5)
PAIR4.controlRight(PAIR6)
PAIR4.controlLeft(PAIR8)
PAIR5.controlUp(PAIR4)
PAIR5.controlDown(PAIR1)
PAIR5.controlRight(CloseButton)
PAIR5.controlLeft(PAIR8)
PAIR6.controlUp(PAIR7)
PAIR6.controlLeft(PAIR1)
PAIR6.controlRight(PAIR8)
PAIR6.controlDown(PAIR7)
PAIR7.controlUp(PAIR6)
PAIR7.controlLeft(PAIR1)
PAIR7.controlRight(PAIR8)
PAIR7.controlDown(CloseButton)
PAIR8.controlUp(PAIR16)
PAIR8.controlLeft(PAIR6)
PAIR8.controlRight(PAIR1)
PAIR8.controlDown(PAIR9)
PAIR9.controlUp(PAIR8)
PAIR9.controlLeft(PAIR6)
PAIR9.controlRight(PAIR1)
PAIR9.controlDown(PAIR10)
PAIR10.controlUp(PAIR9)
PAIR10.controlLeft(PAIR6)
PAIR10.controlRight(PAIR1)
PAIR10.controlDown(PAIR11)
PAIR11.controlUp(PAIR10)
PAIR11.controlLeft(PAIR6)
PAIR11.controlRight(PAIR1)
PAIR11.controlDown(PAIR12)
PAIR12.controlUp(PAIR11)
PAIR12.controlLeft(PAIR6)
PAIR12.controlRight(PAIR1)
PAIR12.controlDown(PAIR13)
PAIR13.controlUp(PAIR12)
PAIR13.controlLeft(PAIR6)
PAIR13.controlRight(PAIR1)
PAIR13.controlDown(PAIR14)
PAIR14.controlUp(PAIR13)
PAIR14.controlLeft(PAIR6)
PAIR14.controlRight(PAIR1)
PAIR14.controlDown(PAIR15)
PAIR15.controlUp(PAIR14)
PAIR15.controlLeft(PAIR6)
PAIR15.controlRight(PAIR1)
PAIR15.controlDown(PAIR16)
PAIR16.controlUp(PAIR15)
PAIR16.controlLeft(CloseButton)
PAIR16.controlRight(PAIR1)
PAIR16.controlDown(PAIR8)
CloseButton.controlUp(PAIR7)
CloseButton.controlLeft(PAIR5)
CloseButton.controlRight(PAIR16)
PUG.setFocus(PAIR1)
PUG.connect(pyxbmct.ACTION_NAV_BACK, PUG.close)
PUG.doModal()
del PUG 
